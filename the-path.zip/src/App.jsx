import { useState, useEffect, useRef } from "react";
import { nodes, PHASES } from "./utils/loadNodes";
import { searchNodes } from "./utils/searchNodes";

// ─────────────────────────────────────────────
//  SEARCH OVERLAY — Cmd/Ctrl+K or "/" from anywhere
// ─────────────────────────────────────────────
function SearchOverlay({ open, onClose, onPick }) {
  const [q, setQ] = useState("");
  const [sel, setSel] = useState(0);
  const inputRef = useRef(null);
  const results = q.trim() ? searchNodes(q, 12) : [];

  useEffect(() => {
    if (open) {
      setQ("");
      setSel(0);
      setTimeout(() => inputRef.current?.focus(), 20);
    }
  }, [open]);

  useEffect(() => { setSel(0); }, [q]);

  if (!open) return null;

  const pick = (id) => { if (id) { onPick(id); onClose(); } };

  const onKey = (e) => {
    if (e.key === "Escape") { e.preventDefault(); onClose(); return; }
    if (e.key === "ArrowDown") { e.preventDefault(); setSel((s) => Math.min(s + 1, results.length - 1)); }
    if (e.key === "ArrowUp") { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
    if (e.key === "Enter") { e.preventDefault(); pick(results[sel]?.id); }
  };

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, zIndex: 1000,
        background: "rgba(4,6,9,0.78)", backdropFilter: "blur(2px)",
        display: "flex", alignItems: "flex-start", justifyContent: "center",
        paddingTop: "12vh",
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "min(680px, 92vw)", background: "#0c1017",
          border: "1px solid #2a3648", borderRadius: 8,
          boxShadow: "0 20px 60px rgba(0,0,0,0.6)", overflow: "hidden",
          fontFamily: "'JetBrains Mono','Fira Code',monospace",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "14px 16px", borderBottom: "1px solid #1a2432" }}>
          <span style={{ color: "#4a9eff", fontSize: 16 }}>⌕</span>
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={onKey}
            placeholder="Search all nodes — ligolo, venv, kerberoast, SeImpersonate…"
            style={{
              flex: 1, background: "transparent", border: "none", outline: "none",
              color: "#cdd6e0", fontSize: 15, fontFamily: "inherit",
            }}
          />
          <kbd style={{ color: "#54627a", fontSize: 11, border: "1px solid #263243", borderRadius: 4, padding: "2px 6px" }}>esc</kbd>
        </div>

        <div style={{ maxHeight: "56vh", overflowY: "auto" }}>
          {q.trim() && results.length === 0 && (
            <div style={{ padding: "22px 16px", color: "#54627a", fontSize: 13 }}>
              No nodes match “{q}”. Try a tool name, CVE, or command fragment.
            </div>
          )}
          {results.map((r, i) => {
            const ph = PHASES[r.phase];
            const active = i === sel;
            return (
              <div
                key={r.id}
                onMouseEnter={() => setSel(i)}
                onClick={() => pick(r.id)}
                style={{
                  padding: "10px 16px", cursor: "pointer",
                  background: active ? "#141c28" : "transparent",
                  borderLeft: active ? "2px solid #4a9eff" : "2px solid transparent",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  {r.phase && (
                    <span style={{
                      fontSize: 10, letterSpacing: 1, textTransform: "uppercase",
                      color: ph?.color || "#8899aa",
                      border: `1px solid ${ph?.color || "#8899aa"}33`,
                      borderRadius: 3, padding: "1px 6px",
                    }}>{r.phase}</span>
                  )}
                  <span style={{ color: "#e3ebf5", fontSize: 14 }}>{r.title}</span>
                  <span style={{ color: "#3a4656", fontSize: 11, marginLeft: "auto" }}>{r.id}</span>
                </div>
                {r.snippet && (
                  <div style={{ color: "#6b7a90", fontSize: 12, marginTop: 4, lineHeight: 1.4 }}>{r.snippet}</div>
                )}
              </div>
            );
          })}
        </div>

        <div style={{ padding: "8px 16px", borderTop: "1px solid #1a2432", display: "flex", gap: 16, color: "#54627a", fontSize: 11 }}>
          <span>↑↓ navigate</span>
          <span>⏎ open</span>
          <span>esc close</span>
          <span style={{ marginLeft: "auto" }}>{results.length ? `${results.length} result${results.length > 1 ? "s" : ""}` : ""}</span>
        </div>
      </div>
    </div>
  );
}


// ─────────────────────────────────────────────
//  COMPONENT
// ─────────────────────────────────────────────
export default function OSCPAdventure() {
  const [history, setHistory] = useState(["start"]);
  const [copied, setCopied] = useState(false);
  const [animKey, setAnimKey] = useState(0);
  const [showAbout, setShowAbout] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const topRef = useRef(null);

  const currentId = history[history.length - 1];
  const node = nodes[currentId];
  const phase = PHASES[node.phase] || PHASES.RECON;

  const go = (next) => {
    setHistory((h) => [...h, next]);
    setAnimKey((k) => k + 1);
    setTimeout(() => topRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
  };

  const back = () => {
    if (history.length > 1) {
      setHistory((h) => h.slice(0, -1));
      setAnimKey((k) => k + 1);
    }
  };

  const reset = () => {
    setHistory(["start"]);
    setAnimKey((k) => k + 1);
  };

  const copyCmd = () => {
    if (node.cmd) {
      navigator.clipboard.writeText(node.cmd);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    }
  };



  const [copiedMd, setCopiedMd] = useState(false);

  const copyObsidian = () => {
    // Template nodes paste their raw markdown verbatim — no technique scaffolding.
    if (node.template && node.markdown) {
      navigator.clipboard.writeText(node.markdown);
      setCopiedMd(true);
      setTimeout(() => setCopiedMd(false), 1800);
      return;
    }
    const lines = [];
    lines.push(`# ${node.title}`);
    lines.push(`**Phase:** ${node.phase}  `);
    lines.push(`**Date:** ${new Date().toISOString().slice(0,10)}  `);
    lines.push(`**Node:** \`${currentId}\``);
    lines.push('');
    lines.push('## Guidance');
    lines.push(node.body);
    lines.push('');
    if (node.warn) {
      lines.push('> [!warning]');
      lines.push(`> ${node.warn}`);
      lines.push('');
    }
    if (node.cmd) {
      lines.push('## Commands');
      lines.push('```bash');
      lines.push(node.cmd);
      lines.push('```');
      lines.push('');
    }
    lines.push('## What I Found');
    lines.push('');
    lines.push('```');
    lines.push('');
    lines.push('```');
    lines.push('');
    lines.push('## Proof / Evidence');
    lines.push('');
    lines.push('- Screenshot: ');
    lines.push('- Output: ');
    lines.push('');
    lines.push('## Next Move');
    lines.push('');
    node.choices.forEach(c => {
      lines.push(`- [ ] ${c.label} → \`${c.next || c.href || "external"}\``);
    });
    lines.push('');
    lines.push('---');
    lines.push('*Generated by The Path — OSCP Field Guide*');
    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedMd(true);
    setTimeout(() => setCopiedMd(false), 1800);
  };

  const phaseList = history.map((h) => nodes[h]?.phase).filter(Boolean);

  useEffect(() => {
    const handleKey = (e) => {
      // Cmd/Ctrl+K opens search from anywhere, even while typing in a field.
      if ((e.metaKey || e.ctrlKey) && (e.key === "k" || e.key === "K")) {
        e.preventDefault(); setShowSearch(true); return;
      }
      // Search overlay owns its own keys while open.
      if (showSearch) return;
      if (showAbout) { if (e.key === "Escape") setShowAbout(false); return; }
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      // "/" opens search (common convention), like GitHub / docs sites.
      if (e.key === "/") { e.preventDefault(); setShowSearch(true); return; }
      const num = parseInt(e.key);
      if (!isNaN(num) && num >= 1 && num <= node.choices.length) {
        const choice = node.choices[num - 1]; if (choice.href) window.open(choice.href, "_blank"); else go(choice.next);
      }
      if (e.key === "Backspace" || e.key === "ArrowLeft") back();
      if (e.key === "r" || e.key === "R") reset();
      if (e.key === "?" || e.key === "a" || e.key === "A") setShowAbout(true);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [node, history, showAbout, showSearch]);

  return (
    <div style={{
      minHeight: "100vh",
      background: "#080b0f",
      color: "#cdd6e0",
      fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
    }}>

      <SearchOverlay open={showSearch} onClose={() => setShowSearch(false)} onPick={(id) => go(id)} />

      {/* ── HEADER ─────────────────────────── */}
      <header ref={topRef} style={{
        width: "100%",
        background: "linear-gradient(180deg, #0c1018 0%, #080b0f 100%)",
        borderBottom: `1px solid ${phase.color}33`,
        padding: "14px 28px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        position: "sticky",
        top: 0,
        zIndex: 20,
        boxSizing: "border-box",
        boxShadow: `0 1px 30px ${phase.color}18`,
        transition: "border-color 0.4s, box-shadow 0.4s",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.1 }}>
            <div style={{
              fontSize: 17,
              fontWeight: 800,
              letterSpacing: 5,
              color: phase.color,
              textShadow: `0 0 16px ${phase.color}`,
              textTransform: "uppercase",
              transition: "color 0.4s, text-shadow 0.4s",
            }}>
              THE PATH
            </div>
            <div style={{
              fontSize: 10,
              letterSpacing: 3,
              color: "#3a4858",
              textTransform: "uppercase",
              marginTop: 2,
            }}>
              OSCP Field Guide
            </div>
          </div>
          <div style={{
            width: 1,
            height: 16,
            background: "#2a3040",
          }} />
          <div style={{
            fontSize: 17,
            letterSpacing: 3,
            color: "#4a5568",
            textTransform: "uppercase",
          }}>
            {phase.icon} {node.phase}
          </div>
        </div>

        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <a
            href="https://github.com/jimi421/patha"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              background: "transparent",
              border: "1px solid #1e2838",
              color: "#8899aa",
              padding: "5px 12px",
              cursor: "pointer",
              fontFamily: "inherit",
              fontSize: 15,
              letterSpacing: 2,
              borderRadius: 2,
              textTransform: "uppercase",
              textDecoration: "none",
              transition: "all 0.2s",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
            onMouseEnter={e => e.currentTarget.style.borderColor = "#3a4858"}
            onMouseLeave={e => e.currentTarget.style.borderColor = "#1e2838"}
          >
            ⎇ github
          </a>
          <button
            onClick={() => setShowSearch(true)}
            title="Search all nodes (press / or Ctrl+K)"
            style={{
              background: "transparent",
              border: "1px solid #1e2838",
              color: "#8899aa",
              padding: "5px 12px",
              cursor: "pointer",
              fontFamily: "inherit",
              fontSize: 15,
              letterSpacing: 2,
              borderRadius: 2,
              textTransform: "uppercase",
              transition: "all 0.2s",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
            onMouseEnter={e => e.currentTarget.style.borderColor = "#3a4858"}
            onMouseLeave={e => e.currentTarget.style.borderColor = "#1e2838"}
          >⌕ search <kbd style={{ fontSize: 10, color: "#54627a", border: "1px solid #263243", borderRadius: 3, padding: "0 4px", letterSpacing: 0 }}>/</kbd></button>
          <button
            onClick={() => setShowAbout(true)}
            style={{
              background: "transparent",
              border: "1px solid #1e2838",
              color: "#8899aa",
              padding: "5px 12px",
              cursor: "pointer",
              fontFamily: "inherit",
              fontSize: 15,
              letterSpacing: 2,
              borderRadius: 2,
              textTransform: "uppercase",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => e.currentTarget.style.borderColor = "#3a4858"}
            onMouseLeave={e => e.currentTarget.style.borderColor = "#1e2838"}
          >? about</button>
          <button
            onClick={back}
            disabled={history.length <= 1}
            style={{
              background: "transparent",
              border: "1px solid #1e2838",
              color: history.length > 1 ? "#8899aa" : "#2a3040",
              padding: "5px 12px",
              cursor: history.length > 1 ? "pointer" : "default",
              fontFamily: "inherit",
              fontSize: 17,
              letterSpacing: 2,
              borderRadius: 2,
              textTransform: "uppercase",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => { if (history.length > 1) e.currentTarget.style.borderColor = "#3a4858"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "#1e2838"; }}
          >← back</button>

          <button
            onClick={reset}
            style={{
              background: "transparent",
              border: "1px solid #3a1a1a",
              color: "#ff4d6a",
              padding: "5px 12px",
              cursor: "pointer",
              fontFamily: "inherit",
              fontSize: 17,
              letterSpacing: 2,
              borderRadius: 2,
              textTransform: "uppercase",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => e.currentTarget.style.background = "#ff4d6a18"}
            onMouseLeave={e => e.currentTarget.style.background = "transparent"}
          >⟳ reset</button>
        </div>
      </header>

      {/* ── BREADCRUMB TRAIL ───────────────── */}
      <div style={{
        width: "100%",
        maxWidth: 1100,
        padding: "10px 28px 4px",
        boxSizing: "border-box",
        display: "flex",
        alignItems: "center",
        gap: 6,
        flexWrap: "wrap",
        fontSize: 13,
        color: "#3a4858",
        letterSpacing: 1,
        overflowX: "auto",
      }}>
        <span style={{ color: "#2a3848", fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginRight: 4 }}>path:</span>
        {history.map((h, i) => {
          const n = nodes[h];
          const p = PHASES[n?.phase] || PHASES.RECON;
          const isCurrent = i === history.length - 1;
          return (
            <span key={i} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span
                onClick={() => {
                  if (!isCurrent) setHistory(prev => prev.slice(0, i + 1));
                }}
                style={{
                  color: isCurrent ? p.color : "#3a5068",
                  cursor: isCurrent ? "default" : "pointer",
                  background: isCurrent ? `${p.color}12` : "transparent",
                  border: isCurrent ? `1px solid ${p.color}30` : "1px solid transparent",
                  borderRadius: 2,
                  padding: "1px 6px",
                  fontSize: 12,
                  letterSpacing: 1,
                  textTransform: "uppercase",
                  transition: "all 0.2s",
                  whiteSpace: "nowrap",
                }}
                title={isCurrent ? "" : `Jump back to ${n?.title}`}
              >
                {p.icon} {n?.title?.replace(/[^a-zA-Z0-9 \-→]/g, "").trim().slice(0, 22) || h}
              </span>
              {i < history.length - 1 && (
                <span style={{ color: "#1e2838", fontSize: 10 }}>›</span>
              )}
            </span>
          );
        })}
        <span style={{ marginLeft: "auto", color: "#2a3848", fontSize: 11, letterSpacing: 1 }}>
          step {history.length} · press 1-9 to choose · backspace = back
        </span>
      </div>

      {/* ── MAIN CARD ──────────────────────── */}
      <main style={{
        width: "100%",
        maxWidth: 1100,
        padding: "16px 28px 48px",
        boxSizing: "border-box",
      }}>
        <div
          key={animKey}
          style={{
            animation: "fadeSlide 0.25s ease-out both",
          }}
        >
          {/* Card */}
          <div style={{
            background: "#0c1018",
            border: `1px solid ${phase.color}2a`,
            borderRadius: 6,
            overflow: "hidden",
            boxShadow: `0 0 60px ${phase.color}0d`,
            transition: "border-color 0.4s, box-shadow 0.4s",
          }}>

            {/* Card top bar */}
            <div style={{
              background: `linear-gradient(90deg, ${phase.color}14 0%, transparent 70%)`,
              borderBottom: `1px solid ${phase.color}20`,
              padding: "18px 24px 14px",
            }}>
              <div style={{
                fontSize: 16,
                letterSpacing: 4,
                color: phase.color,
                textTransform: "uppercase",
                marginBottom: 8,
                opacity: 0.7,
              }}>
                {`[ ${node.phase} // STEP ${history.length} ]`}
              </div>
              <h1 style={{
                margin: 0,
                fontSize: 26,
                fontWeight: 700,
                color: "#e8f0f8",
                letterSpacing: 0.5,
                lineHeight: 1.2,
              }}>
                {node.title}
              </h1>
            </div>

            {/* Card body */}
            <div style={{ padding: "20px 24px 24px" }}>

              {/* Body text */}
              <p style={{
                margin: "0 0 20px",
                fontSize: 17,
                lineHeight: 1.9,
                color: "#8899aa",
                paddingLeft: 14,
                borderLeft: `2px solid ${phase.color}55`,
              }}>
                {node.body}
              </p>

              {/* Warning */}
              
            {node.warn && (
                <div style={{
                  background: "#1a1200",
                  border: "1px solid #ffd16633",
                  borderLeft: "3px solid #ffd166",
                  borderRadius: "0 4px 4px 0",
                  padding: "10px 14px",
                  marginBottom: 20,
                  fontSize: 15,
                  color: "#ffd166cc",
                  lineHeight: 1.6,
                }}>
                  ⚠ {node.warn}
                </div>
              )}

              {/* Commands */}
              {node.cmd && (
                <div style={{ marginBottom: 24 }}>
                  <div style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 6,
                  }}>
                    <span style={{
                      fontSize: 16,
                      letterSpacing: 3,
                      color: phase.color,
                      textTransform: "uppercase",
                      opacity: 0.8,
                    }}>
                      commands
                    </span>
                    <div style={{ display: "flex", gap: 8 }}>
                    <button
                      onClick={copyCmd}
                      style={{
                        background: copied ? `${phase.color}22` : "transparent",
                        border: `1px solid ${phase.color}44`,
                        color: phase.color,
                        padding: "3px 10px",
                        cursor: "pointer",
                        fontFamily: "inherit",
                        fontSize: 16,
                        letterSpacing: 2,
                        borderRadius: 2,
                        textTransform: "uppercase",
                        transition: "all 0.2s",
                      }}
                    >
                      {copied ? "✓ copied" : "copy"}
                    </button>
                    <button
                      onClick={copyObsidian}
                      style={{
                        background: copiedMd ? "#7c3aed22" : "transparent",
                        border: "1px solid #7c3aed55",
                        color: copiedMd ? "#a78bfa" : "#7c3aed",
                        padding: "3px 10px",
                        cursor: "pointer",
                        fontFamily: "inherit",
                        fontSize: 16,
                        letterSpacing: 2,
                        borderRadius: 2,
                        textTransform: "uppercase",
                        transition: "all 0.2s",
                      }}
                    >
                      {copiedMd ? "✓ vault" : "⟡ obsidian"}
                    </button>
                    
                    </div>
                  </div>
                  <pre style={{
                    background: "#060a0e",
                    border: `1px solid #1a2838`,
                    borderLeft: `3px solid ${phase.color}88`,
                    padding: "16px 18px",
                    margin: 0,
                    fontSize: 15,
                    lineHeight: 1.75,
                    color: "#7ecb9e",
                    overflowX: "auto",
                    borderRadius: "0 4px 4px 0",
                    whiteSpace: "pre",
                  }}>
                    {node.cmd}
                  </pre>
                </div>
              )}

              {/* Choices */}
              <div>
                <div style={{
                  fontSize: 16,
                  letterSpacing: 3,
                  color: "#3a4858",
                  textTransform: "uppercase",
                  marginBottom: 10,
                }}>
                  what did you find?
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {node.choices.map((c, i) => {
                    const np = nodes[c.next];
                    const nc = PHASES[np?.phase]?.color || phase.color;
                    return (
                      <button
                        key={i}
                        onClick={() => c.href ? window.open(c.href, "_blank") : go(c.next)}
                        style={{
                          background: `linear-gradient(90deg, ${nc}0c 0%, transparent 80%)`,
                          border: `1px solid ${nc}30`,
                          borderLeft: `3px solid ${nc}66`,
                          color: "#8899aa",
                          padding: "11px 16px",
                          cursor: "pointer",
                          fontFamily: "inherit",
                          fontSize: 16,
                          textAlign: "left",
                          borderRadius: "0 4px 4px 0",
                          transition: "all 0.15s",
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                        }}
                        onMouseEnter={e => {
                          e.currentTarget.style.background = `linear-gradient(90deg, ${nc}1a 0%, transparent 80%)`;
                          e.currentTarget.style.borderLeftColor = nc;
                          e.currentTarget.style.color = "#ddeeff";
                        }}
                        onMouseLeave={e => {
                          e.currentTarget.style.background = `linear-gradient(90deg, ${nc}0c 0%, transparent 80%)`;
                          e.currentTarget.style.borderLeftColor = `${nc}66`;
                          e.currentTarget.style.color = "#8899aa";
                        }}
                      >
                        <span style={{
                          fontSize: 16,
                          color: nc,
                          opacity: 0.8,
                          minWidth: 14,
                          fontWeight: 700,
                        }}>▶</span>
                        {c.label}
                        <span style={{
                          marginLeft: "auto",
                          fontSize: 16,
                          color: nc,
                          opacity: 0.5,
                          letterSpacing: 1,
                          textTransform: "uppercase",
                        }}>
                          {np?.phase}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ── LEGEND ───────────────────────── */}
        <div style={{
          marginTop: 28,
          display: "flex",
          gap: 14,
          flexWrap: "wrap",
          justifyContent: "center",
          fontSize: 16,
          letterSpacing: 2,
          color: "#3a4858",
          textTransform: "uppercase",
        }}>
          {Object.entries(PHASES).filter(([k]) => !["FTP","SSH"].includes(k)).map(([label, { color: c, icon }]) => (
            <div key={label} style={{ display: "flex", alignItems: "center", gap: 5, opacity: node.phase === label ? 1 : 0.5, transition: "opacity 0.3s" }}>
              <div style={{ width: 6, height: 6, background: c, borderRadius: 1, boxShadow: node.phase === label ? `0 0 8px ${c}` : "none", transition: "box-shadow 0.3s" }} />
              {label}
            </div>
          ))}
        </div>
      </main>

      {/* ── ABOUT MODAL ────────────────────── */}
      {showAbout && (
        <div
          onClick={() => setShowAbout(false)}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.85)",
            zIndex: 100,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 24,
          }}
        >
          <div
            onClick={e => e.stopPropagation()}
            style={{
              background: "#0c1018",
              border: "1px solid #3b9eff33",
              borderRadius: 8,
              padding: "36px 40px",
              maxWidth: 560,
              width: "100%",
              fontFamily: "inherit",
              boxShadow: "0 0 80px #3b9eff18",
            }}
          >
            <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: 4, color: "#3b9eff", marginBottom: 6, textTransform: "uppercase" }}>
              The Path
            </div>
            <div style={{ fontSize: 12, letterSpacing: 3, color: "#3a4858", textTransform: "uppercase", marginBottom: 24 }}>
              OSCP Field Guide
            </div>
            <p style={{ color: "#6a7a8a", lineHeight: 1.8, fontSize: 14, marginBottom: 16 }}>
              An interactive decision-tree methodology for OSCP exam day and offensive security practice.
              {' '}{Object.keys(nodes).length} nodes covering every attack domain — web, AD, Linux, Windows, pivoting, shells,
              documentation, and the inner game of operating under pressure.
            </p>
            <p style={{ color: "#6a7a8a", lineHeight: 1.8, fontSize: 14, marginBottom: 24 }}>
              Built for practitioners who need a tool that thinks with them — not just a cheatsheet,
              but a guide that makes decisions, surfaces failure modes, and keeps you oriented
              when the clock is running.
            </p>
            <div style={{ borderTop: "1px solid #1e2838", paddingTop: 20, display: "flex", flexDirection: "column", gap: 8 }}>
              <div style={{ fontSize: 13, color: "#4a5568" }}>
                Built by <span style={{ color: "#cdd6e0" }}>Braxton Bailey</span> <span style={{ color: "#3a4858" }}>(jimi421)</span> — Security practitioner, perpetual student.
              </div>
              <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
                <a href="https://github.com/jimi421/patha" target="_blank" rel="noopener noreferrer"
                  style={{ color: "#3b9eff", fontSize: 13, letterSpacing: 2, textDecoration: "none", textTransform: "uppercase", border: "1px solid #3b9eff33", padding: "4px 12px", borderRadius: 2 }}>
                  ⎇ GitHub
                </a>
                <a href="https://www.linkedin.com/in/braxtonb-dev" target="_blank" rel="noopener noreferrer"
                  style={{ color: "#3b9eff", fontSize: 13, letterSpacing: 2, textDecoration: "none", textTransform: "uppercase", border: "1px solid #3b9eff33", padding: "4px 12px", borderRadius: 2 }}>
                  LinkedIn
                </a>
              </div>
            </div>
            <button
              onClick={() => setShowAbout(false)}
              style={{
                position: "absolute",
                display: "none",
              }}
            />
            <div style={{ marginTop: 20, fontSize: 11, color: "#2a3848", letterSpacing: 1 }}>
              Press ESC to close · Not affiliated with OffSec
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeSlide {
          from { opacity: 0; transform: translateY(8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: #080b0f; }
        ::-webkit-scrollbar-thumb { background: #1e2838; border-radius: 2px; }
        button:focus { outline: none; }
        pre { scrollbar-width: thin; scrollbar-color: #1e2838 #060a0e; }
      `}</style>
    </div>
  );
}
